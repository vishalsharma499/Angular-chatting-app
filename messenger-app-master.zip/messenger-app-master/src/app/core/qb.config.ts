export const qbEndpoints = {
    'api_endpoint': 'https://api.quickblox.com',
    'chat_endpoint': 'chat.quickblox.com',
    'turnserver_endpoint': 'turnserver.quickblox.com'
};

export const qbAccount = {
    appId: 74442,
    authKey: 'pXFrRQMaBGmJUFb',
    authSecret: 'TV-G55Huh62r2nf'
};
